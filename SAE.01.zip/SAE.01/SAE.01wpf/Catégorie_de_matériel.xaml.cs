﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SAE._01wpf
{
    /// <summary>
    /// Logique d'interaction pour Catégorie_de_matériel.xaml
    /// </summary>
    public partial class Catégorie_de_matériel : Window
    {
        public Catégorie_de_matériel()
        {
            InitializeComponent();
        }
    }
}
